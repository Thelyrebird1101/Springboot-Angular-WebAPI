import { Component, OnInit } from '@angular/core';

import {Observable} from 'rxjs';
import {VoucherService} from '../voucher.service';
import {voucher} from "../voucher";
import {Router, ActivatedRoute} from "@angular/router";



@Component({
  selector: 'app-create-voucher',
  templateUrl: './create-voucher.component.html',
  styleUrls: ['./create-voucher.component.css']
})
export class CreateVoucherComponent implements OnInit {
  vch: voucher = new voucher();
  submitted = false;

  constructor(private route: ActivatedRoute, private router: Router, private voucherservice : VoucherService ) { }


  ngOnInit(): void {
  }

  newVoucher(): void{
  this.submitted=false;
  this.vch = new voucher;}

  save(){
  this.voucherservice.createVoucher(this.vch)
    .subscribe(data=>console.log(data), error=>console.log(error));
    this.vch = new voucher();
    }

    onSubmit(){
    this.submitted=true;
    this.save();
    this.gotoList();
     }
    gotoList(){
    this.router.navigate(['/add']);
    }

}
