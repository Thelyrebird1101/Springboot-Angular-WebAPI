import { Component, OnInit } from '@angular/core';
import {Observable} from 'rxjs';
import {VoucherService} from '../voucher.service';
import {voucher} from "../voucher";
import {Router, ActivatedRoute} from "@angular/router";
import {AssignVoucherComponent} from"../assign-voucher/assign-voucher.component";



@Component({
  selector: 'app-voucher-list',
  templateUrl: './voucher-list.component.html',
  styleUrls: ['./voucher-list.component.css']
})
export class VoucherListComponent implements OnInit {
  vouchers = new Observable<voucher[]>();


  constructor(private route: ActivatedRoute, private router: Router, private voucherservice : VoucherService ) { }

  ngOnInit(): void {
  this.reloadData();
  }

  reloadData(){
  this.vouchers = this.voucherservice.getVoucherList();
  }

  assignVoucher(id: number)
  {
  this.router.navigate(['assign', id]);
  }

}
