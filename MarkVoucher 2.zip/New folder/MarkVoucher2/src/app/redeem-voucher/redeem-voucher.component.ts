import { Component, OnInit } from '@angular/core';

import {Observable} from 'rxjs';
import {VoucherService} from '../voucher.service';
import {voucher} from "../voucher";
import {Router, ActivatedRoute} from "@angular/router";
import {customer} from"../customer";



@Component({
  selector: 'app-redeem-voucher',
  templateUrl: './redeem-voucher.component.html',
  styleUrls: ['./redeem-voucher.component.css']
})
export class RedeemVoucherComponent implements OnInit {
  cus : customer;
  coupon: string;
  vch: voucher;

  constructor(private route: ActivatedRoute, private router: Router, private voucherservice : VoucherService) { }

  ngOnInit(): void {

  }

  redeemVoucher(coupon: string){
  this.voucherservice.redeemVoucher(coupon).subscribe(
  data => {
    console.log(data);
   
  },
  error => {console.log(error);
           
            });

}}
