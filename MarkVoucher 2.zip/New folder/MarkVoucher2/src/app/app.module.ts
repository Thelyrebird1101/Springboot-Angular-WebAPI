import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateVoucherComponent } from './create-voucher/create-voucher.component';
import { VoucherDetailsComponent } from './voucher-details/voucher-details.component';
import { VoucherListComponent } from './voucher-list/voucher-list.component';
import { AssignVoucherComponent } from './assign-voucher/assign-voucher.component';
import { RedeemVoucherComponent } from './redeem-voucher/redeem-voucher.component';


@NgModule({
  declarations: [
    AppComponent,
    CreateVoucherComponent,
    VoucherDetailsComponent,
    VoucherListComponent,
    AssignVoucherComponent,
    RedeemVoucherComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
