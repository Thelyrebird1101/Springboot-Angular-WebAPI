import { Component, OnInit } from '@angular/core';

import {Observable} from 'rxjs';
import {VoucherService} from '../voucher.service';
import {voucher} from "../voucher";
import {Router, ActivatedRoute} from "@angular/router";
import {customer} from "../customer";


@Component({
  selector: 'app-assign-voucher',
  templateUrl: './assign-voucher.component.html',
  styleUrls: ['./assign-voucher.component.css']
})
export class AssignVoucherComponent implements OnInit {
  cus: customer;
  id: number;
  vch: voucher;


  constructor(private route: ActivatedRoute, private router: Router, private voucherservice : VoucherService) { }

  ngOnInit(): void {
    this.cus = new customer();
    this.vch = new voucher();
    this.id = this.route.snapshot.params['id'];
    this.voucherservice.getVoucher(this.id)
      .subscribe(data=> {
        console.log(data)
        this.vch=data;
      }, error=> console.log(error));    
  }

  assignVoucher(){
  this.voucherservice.assignVoucher(this.id, this.vch)
  .subscribe(data=> console.log(data), error=> console.log(error));
  this.vch = new voucher();
  this.gotoList();
  }

  gotoList(){
    this.router.navigate(['/coupons']);
    }
  
}
