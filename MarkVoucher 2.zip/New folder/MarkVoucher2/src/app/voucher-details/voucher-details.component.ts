import { Component, OnInit } from '@angular/core';
import {Observable} from 'rxjs';
import {VoucherService} from '../voucher.service';
import {voucher} from "../voucher";
import {Router, ActivatedRoute} from "@angular/router";
import {customer} from "../customer";


@Component({
  selector: 'app-voucher-details',
  templateUrl: './voucher-details.component.html',
  styleUrls: ['./voucher-details.component.css']
})
export class VoucherDetailsComponent implements OnInit {
    cus: customer ;
    vchrs: Observable<voucher[]>;
    phone_r: string;


  constructor(private route: ActivatedRoute, private router: Router, private voucherservice : VoucherService) { }

  ngOnInit(): void{
  
  }

  voucherdetails(phone_r : string)
    {
      this.vchrs = this.voucherservice.getAssignedVoucherList(phone_r);
    }
}
