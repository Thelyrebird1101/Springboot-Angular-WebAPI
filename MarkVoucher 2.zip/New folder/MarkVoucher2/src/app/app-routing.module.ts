import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AssignVoucherComponent } from './assign-voucher/assign-voucher.component';
import { CreateVoucherComponent } from './create-voucher/create-voucher.component';
import { RedeemVoucherComponent } from './redeem-voucher/redeem-voucher.component';
import { VoucherDetailsComponent } from './voucher-details/voucher-details.component';
import { VoucherListComponent } from './voucher-list/voucher-list.component';



const routes: Routes = [

{path: 'coupons', component: VoucherListComponent},
{path: 'add', component: CreateVoucherComponent},
{path: 'assign/:id' , component: AssignVoucherComponent},
{path: 'customer', component: VoucherDetailsComponent},
{path: 'merchant', component: RedeemVoucherComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
