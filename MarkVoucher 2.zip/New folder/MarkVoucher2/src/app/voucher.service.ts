import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class VoucherService {
  private baseUrl= 'http://localhost:8080/MarkVoucher/';
    constructor(private http: HttpClient) { }

    getVoucherList(): Observable<any>{
    return this.http.get(`${this.baseUrl}/coupons`);
    }

    getVoucher(id: number): Observable<any>{
    return this.http.get(`${this.baseUrl}/${id}`);
    }
    getAssignedVoucherList(phone:string): Observable<any>{
    return this.http.get(`${this.baseUrl}/${phone}`);
    }
    createVoucher(vch: Object): Observable<Object>{
    return this.http.post(`${this.baseUrl}/Add`, vch);
    }

    assignVoucher(id: number, value: any): Observable<Object>{
    return this.http.put(`${this.baseUrl}/coupons/${id}`, value);
    }

    redeemVoucher(coupon: string): Observable<any>{
    return this.http.delete(`${this.baseUrl}/redeem/${coupon}`, {responseType:'text'} );
    }
}
