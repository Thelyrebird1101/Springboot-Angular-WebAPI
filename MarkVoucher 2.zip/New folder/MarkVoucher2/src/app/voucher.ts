export class voucher{
id: number;
coupon: string;
val: number;
strt: Date;
expiry: Date;
phone: string;
}
