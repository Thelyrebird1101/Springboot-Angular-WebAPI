export class customer{
phone_r: string;
coupon: string;
}
