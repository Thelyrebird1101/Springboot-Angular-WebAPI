package com.redpandas.MarkVoucher;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarkVoucherApplicationTests {

	@Test
	void contextLoads() {
	}

}
