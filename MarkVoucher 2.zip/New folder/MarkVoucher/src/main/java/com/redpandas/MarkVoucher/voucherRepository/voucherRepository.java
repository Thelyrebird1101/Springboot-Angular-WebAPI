package com.redpandas.MarkVoucher.voucherRepository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.*;

import com.redpandas.MarkVoucher.model.voucher;

@Repository
public interface voucherRepository extends JpaRepository<voucher, Long>{



}
