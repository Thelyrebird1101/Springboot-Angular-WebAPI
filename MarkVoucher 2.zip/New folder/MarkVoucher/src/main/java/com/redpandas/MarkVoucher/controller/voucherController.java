package com.redpandas.MarkVoucher.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.*;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.format.DateTimeFormatter;

import com.redpandas.MarkVoucher.exception.ResourceNotFoundException;
import com.redpandas.MarkVoucher.model.*;
import com.redpandas.MarkVoucher.voucherRepository.*;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/")


public class voucherController {

	@Autowired
	private voucherRepository vrepo;
	
	@GetMapping("/coupons")
	public List<voucher> getValidVouchers(){
		Date d =new Date();
		List<voucher> all = vrepo.findAll();
		List<voucher> valid = null;
		Iterator<voucher> itr =null;
		
		try {
		itr= all.listIterator();
		while(itr.hasNext()) {
			if(((itr.next().getStart().compareTo(d)<=0) && (itr.next().getExpiry().compareTo(d)>=0)) && itr.next().getPhone()==null){
				valid.add(itr.next());
				
			}
		} 
			
		}finally {
			valid = null;
		}
		return valid;
	}
	
	@GetMapping("/{phone}")
	public List<voucher> getAssignedVouchers(String phone){
		List<voucher> all = vrepo.findAll();
		Iterator<voucher> itr =null;
		List<voucher> assigned = null;
		itr = all.listIterator();
		
		try {
			
			while(itr.hasNext()) {
				if(itr.next().getPhone().equals(phone))
					assigned.add(itr.next());
			}}finally{
				assigned = null;			}
			
	return assigned;
	}
	
	@GetMapping("/customer/{id}")
	public ResponseEntity<voucher> getvoucherById(@PathVariable(value = "id") Long cid)
			throws ResourceNotFoundException {
		voucher vch = vrepo.findById(cid)
				.orElseThrow(() -> new ResourceNotFoundException("Not found"));
		return ResponseEntity.ok().body(vch);
	}
	
	
	@PostMapping("/Add")
	public voucher createVoucher(@Valid @RequestBody voucher vch) {
		return vrepo.save(vch);
	}
	
	@PutMapping("/coupons/{code}")
	public ResponseEntity<voucher> updateVoucher(@PathVariable(value = "code") Long cid,
			@Valid @RequestBody voucher vchDetails) throws ResourceNotFoundException {
		voucher vch = vrepo.findById(cid)
				.orElseThrow(() -> new ResourceNotFoundException("No coupon found "));

		vch.setCoupon(vchDetails.getCoupon());
		vch.setValue(vchDetails.getValue());
		vch.setStart(vchDetails.getStart());
		vch.setExpiry(vchDetails.getExpiry());
		vch.setPhone(vchDetails.getPhone());
		
		final voucher updatedVoucher = vrepo.save(vch);
		return ResponseEntity.ok(updatedVoucher);
	}
	
	
	@DeleteMapping("/redeem/{code}")
	public String deleteVoucher(String coupon )
	throws ResourceNotFoundException{
		Date d = new Date();
		List<voucher> all = vrepo.findAll();
		Iterator<voucher> itr =null;
		itr=all.listIterator();
		String response="Not Found";
		long id=0;
		while(itr.hasNext()) {
			if(itr.next().getCoupon().equals(coupon)) {
				id=itr.next().getCode();
				break;
			}
		}
		if(id!=0){voucher vch= vrepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Not Found "));
					vrepo.delete(vch);
					response="Redeemed Successfully";}
		
		
	 return response;
}
	
	
	
	}
	
	

