package com.redpandas.MarkVoucher.model;

import java.util.*;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;


@Entity
@Table(name = "voucher")
public class voucher {
	
@Id
@GeneratedValue(strategy= GenerationType.AUTO, generator="native")
@GenericGenerator(name="native", strategy="native")
@Column(name="id")
private long code;

@Column(name="coupon")
private String coupon;


public String getCoupon() {
	return coupon;
}

public void setCoupon(String coupon) {
	this.coupon = coupon;
}

@Column(name="val")
private int value;

@Column(name="strt", columnDefinition = "DATE")
private Date start;

@Column(name="expiry", columnDefinition = "DATE")
private Date expiry;



@Column(name="assigned")
private String phone;



public String getPhone() {
	return phone;
}

public void setPhone(String phone) {
	this.phone = phone;
}

public long getCode() {
	return code;
}

public void setCode(long code) {
	this.code = code;
}

public int getValue() {
	return value;
}

public void setValue(int value) {
	this.value = value;
}

public Date getStart() {
	return start;
}

public void setStart(Date start) {
	this.start = start;
}

public Date getExpiry() {
	return expiry;
}

public void setExpiry(Date expiry) {
	this.expiry = expiry;
}





}
